#Hver opmærksom på at der hvor du kører disse scripts fra vil der blive oprettet mapper.

#Udpak zip filen til Desktop i en mappe kaldet: gruppe_5

#åben en terminal og naviger til

cd ~/desktop/gruppe_5

#kør scriptsne fra de tilhørende opgave undermapper.

#for at få if sætningen i opgave 3 opfyldt skal der tilføjes linjer til bar.txt, så der er over 10 linjer.

