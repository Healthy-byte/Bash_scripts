#!/bin/bash

tac foo.txt | rev > bar.txt
