#!/bin/bash


tail -n +4 bar.txt > log.txt
first_lines=$(head -n +3 bar.txt)
echo "${first_lines}" > bar.txt

