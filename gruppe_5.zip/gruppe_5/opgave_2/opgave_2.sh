#!/bin/bash

cat foo.txt > bar.txt
tac foo.txt | rev >> bar.txt
