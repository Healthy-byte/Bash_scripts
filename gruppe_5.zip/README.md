# Bash_scripts

#Hver opmærksom på at der hvor du kører disse scripts fra vil der blive oprettet mapper.

#Udpak zip filen til Desktop i en mappe kaldet: gruppe_5

#åben en terminal og naviger til

cd ~/desktop/gruppe_5
  
#kør scriptsne herfra
