#!/bin/bash

mkdir {hovedmappe_1,hovedmappe_2,hovedmappe_3}
mkdir -p hovedmappe_1/A/B/C
mkdir -p hovedmappe_2/A/B/C
mkdir -p hovedmappe_3/A/B/C

antal_linjer=$(wc -l < bar.txt)
echo "${antal_linjer}"
if [[ $antal_linjer -gt 10 ]]; then
mv bar.txt log.txt
cp log.txt hovedmappe_1/A/B/C
cp log.txt hovedmappe_2/A/B/C
cp log.txt hovedmappe_3/A/B/C
fi
